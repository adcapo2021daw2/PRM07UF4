/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q;
import java.util.Objects;
/**
 *
 * @author Adri
 */
public class Partida {
    
    private int codigo;
    private int pJ1;
    private int pJ2;
    private int jugadores;
    private String mJ1;
    private String mJ2;
     
    public Partida(int codigo){
    this.codigo=codigo;
    this.pJ1=0;
    this.pJ2=0;
    this.jugadores=0;
    this.mJ1="";
    this.mJ2="";
   }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getpJ1() {
        return pJ1;
    }

    public void setpJ1(int pJ1) {
        this.pJ1 = pJ1;
    }

    public int getpJ2() {
        return pJ2;
    }

    public void setpJ2(int pJ2) {
        this.pJ2 = pJ2;
    }

    public int getJugadores() {
        return jugadores;
    }

    public void setJugadores(int jugadores) {
        this.jugadores = jugadores;
    }

    public String getmJ1() {
        return mJ1;
    }

    public void setmJ1(String mJ1) {
        this.mJ1 = mJ1;
    }

    public String getmJ2() {
        return mJ2;
    }

    public void setmJ2(String mJ2) {
        this.mJ2 = mJ2;
    }
           
}

