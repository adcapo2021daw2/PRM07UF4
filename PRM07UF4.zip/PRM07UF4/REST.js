const express = require("express");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.json());
var path = require('path');



var partidas = [];
var juga;
var codiP;

class Partida {
    constructor(codigo) {
        this.codigo = codigo;
        this.pJ1 = 0;
        this.pJ2 = 0;
        this.jugadores = 0;
        this.mJ1 = "";
        this.mJ2 = "";
    }
}


app.post("/empezarpartida/:Codigo", (req, res) => {
    let codigo = req.params.Codigo;
    codiP = codigo;
    if(partidas.find(element => element.codigo == codigo) == undefined){
        partidas.push(new Partida(codigo));
        partidas[partidas.length-1].jugadores += 1;
        juga = "1";
    }else{
        console.log("Entrar");
        for (var i = 0; i < partidas.length; i += 1) {
            if (partidas[i].codigo == codigo) {
                console.log(partidas[i].jugadores);
                if (partidas[i].jugadores < 2) {
                    partidas[i].jugadores += 1;
                    juga = "2";
                
                } else {
                    return res.send('Partida completa');
                }
                break;
            }
        }
    }
    res.send();
});


app.put("/Mover/:Codigo/:Juga/:Movimiento", (req, res) => {
    var juga = req.params.Juga;
    var codigo = req.params.Codigo;
    let j = juga.toString();
    console.log(j);
    var i = 0;
    for (; i < partidas.length; i += 1) {
        if (partidas[i].codigo == codigo) {
            if (j == '1') {
                mJ1 = req.params.Movimiento;
                console.log(mJ1);
                partidas[i].mJ1 = mJ1.toString();
            } else if (j == '2') {
                mJ2 = req.params.Movimiento;
                console.log(mJ2);
                partidas[i].mJ2 = mJ2.toString();        
            } else {
                console.log("Codigo del jugador incorrecto");
            }
        
            console.log(typeof j);
        
            var mJ1 = partidas[i].mJ1;
            var mJ2 = partidas[i].mJ2;
            console.log(mJ1);
            console.log(mJ2);
            if (mJ1 != "" && mJ2 != "") {
                if (mJ1 == mJ2) {
                    console.log("Empate");
                } else if (mJ1 == "Tijera") {
                    if (mJ2 == "Papel") {
                        console.log("El jugador 1 ha ganado");
                        partidas[i].puntsJ1 += 1;
                    } else {
                        console.log("El jugador 2 ha ganado");
                        partidas[i].puntsJ2 += 1;
                    }
                } else if (mJ1 == "Papel") {
                    if (mJ2 == "Piedra") {
                        console.log("El jugador 1 ha ganado");
                        partidas[i].pJ1 += 1;
                    } else {
                        console.log("El jugador 2 ha ganado");
                        partidas[i].pJ2 += 1;
                    }
                } else if (mJ1 == "Piedra") {
                    if (mJ2 == "Tijera") {
                        console.log("El jugador 1 ha ganado");
                        partidas[i].pJ1 += 1;
                    } else {
                        console.log("El jugador 2 ha ganado");
                        partidas[i].pJ2 += 1;
                    }
                }
        
                partidas[i].mJ1 = "";
                partidas[i].mJ2 = "";
        
            }
        }
    }
    res.send();

});

app.get("/Resultados/:Codigo", (req, res) => {
    let codigo = req.params.Codigo;
    console.log(codigo);
    for (let i = 0; i < partidas.length; i += 1) {
        console.log(partidas[i].pJ1);
        console.log(partidas[i].codigo);
        
        if (partidas[i].codigo == codigo) {
            console.log(partidas[i].pJ1);
            res.send(partidas[i].pJ1 + "," + partidas[i].pJ2);
        }
    }
});



app.listen(8888, () => {
    console.log(`Servidor ejecutandose por el puerto .`);
});
