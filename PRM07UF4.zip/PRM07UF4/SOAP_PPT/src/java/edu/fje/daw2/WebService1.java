/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.fje.daw2;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Lenovo
 */
@WebService(serviceName = "WebService1")
public class WebService1 {
    
   public ArrayList<Partida> partidas = new ArrayList<>();
       private int i;
       private String p;
    
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "empezarpartida")
    public void empezarpartida(@WebParam (name = "codigo") int codigo) {
    partidas.add(new Partida(codigo));
    }
     @WebMethod(operationName = "mover")
    public void mover(@WebParam (name = "codigo") int codigo,@WebParam (name = "juga") String juga,@WebParam (name = "tirada") String tirada){
    
            if(juga.equals('1')){
            partidas.get(i).setmJ1(tirada);
        }else if(juga.equals('2')){
            partidas.get(i).setmJ2(tirada);
        }
        
        if(!partidas.get(i).getmJ1().equals("") || !partidas.get(i).getmJ2().equals("")){
            
            if(partidas.get(i).getmJ1().equals(partidas.get(i).getmJ2())){
                System.out.println("Empate");
            }else if(partidas.get(i).getmJ1().equals("tijeras")){
                if(partidas.get(i).getmJ2().equals("papel")){
                    System.out.println("El jugador 1 ha ganado");
                    partidas.get(i).setpJ1(partidas.get(i).getpJ1() + 1);
                }else{
                    System.out.println("El jugador 2 ha ganado");
                    partidas.get(i).setpJ2(partidas.get(i).getpJ2() + 1);
                }
                
            }else if(partidas.get(i).getmJ1().equals("papel")){             
                if(partidas.get(i).getmJ2().equals("piedra")){
                    System.out.println("El jugador 1 ha ganado");
                    partidas.get(i).setpJ1(partidas.get(i).getpJ1() + 1);
                }else{
                    System.out.println("El jugador 2 ha ganado");
                    partidas.get(i).setpJ2(partidas.get(i).getpJ2() + 1);
                }
                
            }else if(partidas.get(i).getmJ1().equals("piedra")){              
                if(partidas.get(i).getmJ2().equals("tijeras")){
                    System.out.println("El jugador 1 ha ganado");
                    partidas.get(i).setpJ1(partidas.get(i).getpJ1() + 1);
                }else{
                    System.out.println("El jugador 2 ha ganado");
                    partidas.get(i).setpJ2(partidas.get(i).getpJ2() + 1);
                }
            
            }
    }
    

    }
}