const express  = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const app = express();
app.use(express.static('public'));

const partidas = [];

class Partida {
    constructor(codigo) {
        this.codigo = codigo;
        this.pJ1 = 0;
        this.pJ2 = 0;
        this.jugadores = 0;
        this.mJ1 = "";
        this.mJ2 = "";
    }
}



const esquema = buildSchema(`

    type partida {
        codigo: Int!
        pJ1: Int
        pJ2: Int
        jugadores: Int
        mJ1: String
        mJ2: String
    }
    type Mutation {
        empezarpartida(codigo: Int): String
         Mover(codigo: Int, juga: Int, tirada: String): Boolean
     }
 

    type Query{
        Resultados(codigo: Int): String

    }

  
`);

const arrel = {
    empezarpartida: ({codigo}) => {
        codiP = codigo;
        if(partidas.find(element => element.codigo == codigo) == undefined){
            partidas.push(new Partida(codigo));
            partidas[partidas.length-1].jugadores += 1;
            juga = "1";
            return juga;
        }else{
            for (var i = 0; i < partidas.length; i += 1) {
                if (partidas[i].codigo == codigo) {
                   
                    console.log("ENTRA PARTIDA");
                    console.log(partidas[i].jugadores);
                    if (partidas[i].jugadores < 2) {
                        partidas[i].jugadores += 1;
                        juga = "2";
                        return juga;
                    
                    } else {
                        return res.send('Partida completa');
                    }
                }
            }
        }
    
    },


    Resultados: ({codigo}) => {
        let p = partidas.find(c => c.codigo == codigo);
        return p.pJ1 + "-" + p.pJ2;
    },



    Mover: ({codigo, juga, tirada}) => {

    for (let i=0; i < partidas.length; i += 1) {
        if (partidas[i].codigo == codigo) {

                if(juga == '1'){
                    partidas[i].mJ1 = tirada;
                }else if(juga == '2') {
                    partidas[i].mJ2 = tirada;
                }else{
                    console.log("El jugador es incorrecto");
                }

                let mJ1 = partidas[i].mJ1;
                let mJ2 = partidas[i].mJ2;

                console.log(mJ1);
                console.log(mJ2);

                if(mJ1 != "" && mJ2 != ""){
                    if(mJ1 == mJ2){
                        console.log("Empate");
                    } 
                    else if (mJ1 == "tijera") {
                        if (mJ2 == "papel") {
                            console.log("El jugador 1 ha ganado");
                            partidas[i].pJ1 += 1;
                        } else {
                            console.log("El jugador 2 ha ganado");
                            partidas[i].pJ2 += 1;
                        }
                    } 
                    else if (mJ1 == "papel") {
                        if (mJ2 == "piedra") {
                            console.log("El jugador 1 ha ganado");
                            partidas[i].pJ1 += 1;
                        } else {
                            console.log("El jugador 2 ha ganado");
                            partidas[i].pJ2 += 1;
                        }
                    } 
                    else if (mJ1 == "piedra") {
                        if (mJ2 == "tijera") {
                            console.log("El jugador 1 ha ganado");
                            partidas[i].pJ1 += 1;
                        } else {
                            console.log("j2 guanya");
                            partidas[i].pJ2 += 1;
                        }
                    }
                    partidas[i].mJ1 = "";
                    partidas[i].mJ2 = "";
                }
            }
            return true;
        }
    }
};
app.use('/graphql', graphqlHTTP({
    schema: esquema,
    rootValue: arrel,
    graphiql: true,
}));


app.listen(4000);
console.log('Servidor iniciat');

